package net.runith.clan.api;

import net.runith.clan.api.config.container.ConfigContainer;
import net.runith.clan.api.leaderboard.Leaderboards;
import net.runith.clan.api.storage.ClanDatabase;
import net.runith.clan.api.storage.ClanRoleStorage;
import net.runith.clan.api.storage.ClansStorage;

public record ClanAPI(
    ClansStorage storage,
    ClanRoleStorage roleStorage,
    ClanDatabase database,
    Leaderboards leaderboards,
    ConfigContainer configContainer
) {
    private static ClanAPI instance;

    public static void setInstance(final ClanAPI instance) {
        if (ClanAPI.instance != null) {
            throw new IllegalStateException("Already set clans api");
        }
        ClanAPI.instance = instance;
    }

    public static ClanAPI getInstance() {
        return instance;
    }
}