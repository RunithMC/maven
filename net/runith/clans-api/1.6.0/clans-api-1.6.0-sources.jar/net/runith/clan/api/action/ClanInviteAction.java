package net.runith.clan.api.action;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import net.runith.clan.api.action.helper.ActionExecutorHolder;
import net.runith.clan.api.model.Clan;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@RequiredArgsConstructor
@Getter
public final class ClanInviteAction {
    @Setter
    private Clan clan;

    private final @NotNull Player target;
    private final Player sender;
    private final @NotNull State state;
    private final long expirationDate;

    public static final ActionExecutorHolder<Response, ClanInviteAction> EXECUTOR = new ActionExecutorHolder<>();

    public static ClanInviteAction accept(final Player target) {
        return new ClanInviteAction(target, null, State.ACCEPT, -1);
    }

    public static ClanInviteAction deny(final Player target) {
        return new ClanInviteAction(target, null, State.DENY, -1);
    }

    public static ClanInviteAction invite(final Player target, final Player sender, final long expirationDate) {
        return new ClanInviteAction(target, sender, State.INVITE, expirationDate);
    }

    public enum ResponseStatus {
        NO_PERMISSIONS,
        NO_IN_CLAN,
        ALREADY_IN_CLAN,
        ALREADY_IN_OTHER_CLAN,
        ALREADY_INVITED,
        ALREADY_INVITED_BY_OTHER_CLAN,
        NO_INVITED,
        MAX_MEMBERS,
        DENIED,
        INVITED,
        ACCEPTED;

        public boolean isSuccessfully() {
            return this == DENIED || this == INVITED || this == ACCEPTED;
        }
    }

    public enum State {
        INVITE,
        ACCEPT,
        DENY
    }

    public record Response(@Nullable Clan clan, @Nullable Player sender, @NotNull ResponseStatus status){}
}