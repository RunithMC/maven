package net.runith.clan.api.event.chat;

import lombok.Getter;
import lombok.Setter;
import net.runith.clan.api.model.ChatMode;
import net.runith.clan.api.model.Clan;
import net.runith.clan.api.model.ClanMember;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Getter
@Setter
public class ClanChatEvent extends Event implements Cancellable {

    private static final HandlerList HANDLER_LIST = new HandlerList();
    private final @NotNull ClanMember member;
    private final @NotNull Clan clanToChat;

    private boolean cancelled;
    private @Nullable String prefixSend, prefixReceive, prefixSpy;
    private @NotNull String message;

    public ClanChatEvent(
        final @NotNull ClanMember member,
        final @NotNull Clan clanToChat,
        final @NotNull String message,
        final @Nullable String prefixSend,
        final @Nullable String prefixReceive,
        final @Nullable String prefixSpy
    ) {
        super(true);
        this.member = member;
        this.clanToChat = clanToChat;
        this.message = message;
        this.prefixSend = prefixSend;
        this.prefixReceive = prefixReceive;
        this.prefixSpy = prefixSpy;
    }

    public Player getPlayer() {
        return member.getPlayer();
    }

    public @NotNull ChatMode getChatMode() {
        return member.getChatMode();
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLER_LIST;
    }

    public static HandlerList getHandlerList() {
        return HANDLER_LIST;
    }
}