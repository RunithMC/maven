package net.runith.clan.api.model;

import lombok.Getter;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

public record MemberRole(
    @NotNull Set<String> permissions,
    @NotNull Type type
) {

    @Getter
    public enum Type {
        ADMIN(4),
        LEADER(3),
        CO_LEADER(2),
        MOD(1),
        USER(0);

        private final int priority;

        Type(int priority) {
            this.priority = priority;
        }
    }

    public boolean hasPermission(final String permission) {
        return type.priority == Type.ADMIN.priority || permissions.contains(permission);
    }

    public int priority() {
        return type.priority;
    }

    public String name() {
        return type.name();
    }
}