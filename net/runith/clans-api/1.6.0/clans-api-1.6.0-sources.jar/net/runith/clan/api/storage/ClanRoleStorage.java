package net.runith.clan.api.storage;

import net.runith.clan.api.model.MemberRole;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;

public interface ClanRoleStorage {
    @Nullable MemberRole getByPriority(final int priority);
    MemberRole getByName(final String name);
    MemberRole getByType(final MemberRole.Type type);
    MemberRole getOrLeastPriority(final  String name);
    MemberRole getLeastPriorityRank();
    Collection<MemberRole> getRoles();
}