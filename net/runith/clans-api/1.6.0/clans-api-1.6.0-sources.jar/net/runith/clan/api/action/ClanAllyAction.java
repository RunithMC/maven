package net.runith.clan.api.action;

import lombok.Getter;
import net.runith.clan.api.action.helper.ActionExecutorHolder;
import net.runith.clan.api.model.Clan;
import org.bukkit.entity.Player;

@Getter
public final class ClanAllyAction {
    public static final ActionExecutorHolder<Response, ClanAllyAction> EXECUTOR = new ActionExecutorHolder<>();

    public enum State { REQUEST, ACCEPT, DENY, CANCEL, REMOVE }

    public enum ResponseStatus {
        REQUEST_SENT,
        REQUEST_RECEIVED,
        ACCEPTED,
        DENIED,
        CANCELLED,
        REMOVED,
        ALREADY_ALLIED,
        ALREADY_REQUESTED,
        NOT_ALLIED,
        CANNOT_ALLY_YOURSELF,
        CANNOT_ALLY_ENEMY,
        MAX_ALLIES,
        TARGET_MAX_ALLIES,
        CLAN_NOT_FOUND,
        NO_PENDING_REQUEST
    }

    private final State state;
    private final Clan clan1;
    private final Clan clan2;
    private final Player sender;
    private final long expirationDate;

    private ClanAllyAction(State state, Clan clan1, Clan clan2, Player sender, long expirationDate) {
        this.state = state;
        this.clan1 = clan1;
        this.clan2 = clan2;
        this.sender = sender;
        this.expirationDate = expirationDate;
    }

    public static ClanAllyAction request(Clan clan1, Clan clan2, Player sender, long expirationDate) {
        return new ClanAllyAction(State.REQUEST, clan1, clan2, sender, expirationDate);
    }

    public static ClanAllyAction accept(Clan clan1, Clan clan2) {
        return new ClanAllyAction(State.ACCEPT, clan1, clan2, null, 0);
    }

    public static ClanAllyAction deny(Clan clan1, Clan clan2) {
        return new ClanAllyAction(State.DENY, clan1, clan2, null, 0);
    }

    public static ClanAllyAction cancel(Clan clan1, Clan clan2) {
        return new ClanAllyAction(State.CANCEL, clan1, clan2, null, 0);
    }

    public static ClanAllyAction remove(Clan clan1, Clan clan2) {
        return new ClanAllyAction(State.REMOVE, clan1, clan2, null, 0);
    }

    public record Response(ResponseStatus status, Clan clan1, Clan clan2, Player sender) {}
}