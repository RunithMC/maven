package net.runith.clan.api.config;

import lombok.Data;

@Data
public final class ChatConfig {
    private String
        clan,
        enemyReceive, enemySend,
        allyReceive, allySend;
}

