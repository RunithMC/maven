package net.runith.clan.api.model;

import lombok.*;
import net.runith.clan.api.util.StringUtil;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.time.Instant;
import java.util.UUID;

@Getter
@Setter
@ToString
@RequiredArgsConstructor
public final class ClanMember {
    private @NotNull String name;
    private final @NotNull UUID uuid;
    private final @NotNull Clan clan;
    private final @NotNull Instant joinDate;

    private @NotNull MemberRole role;
    private @NotNull ChatMode chatMode = ChatMode.GLOBAL;
    private UUID clanToChat;

    private Player player;
    private Instant lastActive;

    public boolean isOnline() {
        return player != null && player.isOnline();
    }

    @Override
    public boolean equals(final Object obj) {
        return obj instanceof ClanMember clanMember && clanMember.uuid.equals(this.uuid);
    }

    @Override
    public int hashCode() {
        return uuid.hashCode();
    }

    public void setClanToChat(final String clan) {
        this.clanToChat = clan != null ? StringUtil.stringToUUID(clan) : null;
    }
}