package net.runith.clan.api.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import net.runith.clan.api.model.Clan;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@EqualsAndHashCode(callSuper = true)
@Data
public final class ClanAllyRemoveEvent extends Event {
    private static final HandlerList HANDLER_LIST = new HandlerList();
    private final Clan clan;
    private final Clan ally;

    public ClanAllyRemoveEvent(final Clan clan, final Clan ally) {
        super(true);
        this.clan = clan;
        this.ally = ally;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLER_LIST;
    }

    public static HandlerList getHandlerList() {
        return HANDLER_LIST;
    }
}