package net.runith.clan.api.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import net.runith.clan.api.model.Clan;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@EqualsAndHashCode(callSuper = true)
@Data
public final class ClanEnemyAddEvent extends Event {
    private static final HandlerList HANDLER_LIST = new HandlerList();
    private final Clan clan;
    private final Clan enemyClan;

    public ClanEnemyAddEvent(final Clan clan, final Clan enemyClan) {
        super(false);
        this.clan = clan;
        this.enemyClan = enemyClan;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLER_LIST;
    }

    public static HandlerList getHandlerList() {
        return HANDLER_LIST;
    }
}