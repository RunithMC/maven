package net.runith.clan.api.cost;

import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.function.IntToLongFunction;

public final class CostFunctions {

    public static final CostPair NONE_COST_PAIR = staticCostPair(0L);

    public interface CumCost {
        // Sum of costs from fromLevel (exclusive) to toLevel (inclusive). If toLevel <= fromLevel, returns 0.
        long sum(int fromLevel, int toLevel);
    }

    public static final class CostPair {
        public final IntToLongFunction unit; // Cost of level L: unit.apply(L)
        public final CumCost cum;            // Cost of going from level A to B: cum.sum(A, B)

        public CostPair(IntToLongFunction unit, CumCost cum) {
            this.unit = unit;
            this.cum = cum;
        }
    }

    public static @NotNull CostPair staticCostPair(long value) {
        return new CostPair(
            ignore -> value,
            (a,b) -> (b <= a) ? 0L : value * (b - a)
        );
    }

    public static @NotNull CostPair multiplyCostPair(double base, double factor) {
        return new CostPair(
            // Cost of L=0: base, L=1: base*factor, L=2: base*factor^2, ...
            l -> Math.round(base * Math.pow(factor, l)),
            (a, b) -> {
                if (b <= a) return 0L;
                if (factor == 1.0D) {
                    return Math.round(base * (b - a));
                }
                // Geometric sum
                double startTerm = base * Math.pow(factor, a + 1);
                double sum = startTerm * (Math.pow(factor, b - a) - 1.0D) / (factor - 1.0D);
                return Math.round(sum);
            }
        );
    }

    public static @NotNull CostPair addCostPair(long value) {
        return new CostPair(
            l -> Math.multiplyExact(l, value),
            (a, b) -> {
                if (b <= a) return 0L;
                long Ta = triangle(a);
                long Tb = triangle(b);
                long diff = Math.subtractExact(Tb, Ta);
                return Math.multiplyExact(value, diff);
            }
        );
    }

    public static long triangle(long n) {
        // n(n+1)/2 with overflow checks. For n<=1e9, n(n+1) <= 1e18 < 2^63, so no overflow in long. Here n<=25k => safe.
        return (n * (n + 1L)) / 2L;
    }

    public static CostPair fromConfig(Map<String, ?> section) {
        final String type;
        if (section == null || (type = (String) section.get("type")) == null || "NONE".equalsIgnoreCase(type)) {
            return NONE_COST_PAIR;
        }
        final long value = section.get("value") instanceof Number num ? num.longValue() : 0L;
        return switch (type.toUpperCase()) {
            case "STATIC" -> staticCostPair(value);
            case "ADD" -> addCostPair(value);
            case "MULTIPLY" -> multiplyCostPair(value, section.get("multiply-factor") instanceof Number num ? num.doubleValue() : 1.0D);
            default -> NONE_COST_PAIR;
        };
    }
}