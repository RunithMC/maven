package net.runith.clan.api.model;

import java.util.UUID;

public record ClanRally(
    long executedTimeInMillis,
    UUID activeRallyCreator,
    String world,
    int x,
    int y,
    int z,
    String creatorName
) {}