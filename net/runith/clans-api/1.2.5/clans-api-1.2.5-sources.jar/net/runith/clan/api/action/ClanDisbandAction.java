package net.runith.clan.api.action;

import net.runith.clan.api.action.helper.ActionExecutorHolder;
import net.runith.clan.api.model.Clan;
import org.jetbrains.annotations.NotNull;

public record ClanDisbandAction(
    @NotNull Clan clan
) {
    public static final ActionExecutorHolder<Clan, ClanDisbandAction> EXECUTOR = new ActionExecutorHolder<>();

}