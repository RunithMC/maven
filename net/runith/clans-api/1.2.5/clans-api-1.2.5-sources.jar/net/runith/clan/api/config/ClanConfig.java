package net.runith.clan.api.config;

import net.runith.clan.api.model.Clan;
import net.runith.clan.api.util.ObjectToInt;
import net.runith.sdk.lang.MultiLang;

import java.util.Set;

import lombok.Data;

@Data
public final class ClanConfig {
    private ObjectToInt<Clan> scoreCalculator;

    private int invitationExpirationTimeInSeconds;
    private int maxMembers;
    private int maxEnemies;
    private int maxAllies;
    private long renameCooldown;

    private String placeholderTopEntry;
    private long millisToDespawnRally;
    private Set<String> baseBlacklistedWorlds;
    private MultiLang lang;
}