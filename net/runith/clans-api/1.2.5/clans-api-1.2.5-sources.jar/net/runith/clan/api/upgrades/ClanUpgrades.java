package net.runith.clan.api.upgrades;

import lombok.experimental.UtilityClass;
import net.runith.clan.api.upgrades.type.ExtraMemberUpgrade;
import net.runith.clan.api.upgrades.type.PercentageUpgrade;
import net.runith.clan.api.upgrades.type.ProbabilityUpgrade;
import net.runith.clan.api.upgrades.type.Upgrade;

@UtilityClass
public final class ClanUpgrades {
    public static final int MAX_ID = 8;

    public static final Upgrade[] UPGRADES = new Upgrade[MAX_ID];
    public static final PercentageUpgrade
        DAMAGE = register(
            new PercentageUpgrade("extra-damage", 0)),
        RESISTANCE = register(
            new PercentageUpgrade("extra-resistance", 1));

    public static final ExtraMemberUpgrade
        EXTRA_MEMBERS = register(
            new ExtraMemberUpgrade("extra-members", 2)),
        EXTRA_ALLIES = register(
            new ExtraMemberUpgrade("extra-allies", 3)),
        EXTRA_ENEMIES = register(
            new ExtraMemberUpgrade("extra-enemies", 4));

    public static final ProbabilityUpgrade
        EXTRA_KILL_PER_MEMBER = register(
            new ProbabilityUpgrade("extra-kill-per-enemy", 5));

    public static <T extends Upgrade> T register(final T upgrade) {
        UPGRADES[upgrade.getId()] = upgrade;
        return upgrade;
    }
}
