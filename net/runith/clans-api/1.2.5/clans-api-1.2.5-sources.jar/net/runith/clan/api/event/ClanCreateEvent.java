package net.runith.clan.api.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import net.runith.clan.api.model.Clan;
import net.runith.clan.api.model.ClanMember;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@EqualsAndHashCode(callSuper = true)
@Data
public final class ClanCreateEvent extends Event {
    private static final HandlerList HANDLER_LIST = new HandlerList();
    private final ClanMember leader;

    public ClanCreateEvent(final ClanMember leader) {
        super(true);
        this.leader = leader;
    }

    public Clan getClan() {
        return leader.getClan();
    }

    public Player getPlayer() {
        return leader.getPlayer();
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLER_LIST;
    }

    public static HandlerList getHandlerList() {
        return HANDLER_LIST;
    }
}