package net.runith.clan.api.upgrades.type;

import lombok.Getter;
import lombok.Setter;

import java.text.DecimalFormat;
import java.util.Random;

@Getter
@Setter
public class ProbabilityUpgrade extends Upgrade {
    private static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#.#####");
    private static final Random RANDOM = new Random();

    private double probabilityPerLevel;
    private double baseProbability;

    public ProbabilityUpgrade(final String name, final int internalID) {
        super(name, internalID);
    }

    public boolean checkProbability(final int level) {
        if (level <= 0) {
            return false;
        }
        final double probability = baseProbability + (probabilityPerLevel * level);
        return probability >= 100 || RANDOM.nextDouble(100) < probability;
    }

    public String getProbabilityInString(final int level) {
        return DECIMAL_FORMAT.format(Math.min(100, baseProbability + (probabilityPerLevel * level)));
    }

    public String toString() {
        return "probabilityPerLevel=" + probabilityPerLevel + ", baseProbability=" + baseProbability + ", " + super.toString();
    }
}