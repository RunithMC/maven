package net.runith.clan.api.storage;

import lombok.AllArgsConstructor;
import lombok.Data;
import net.runith.clan.api.model.ClanMember;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

@Data
@AllArgsConstructor
public final class PlayerClanData {
    private @Nullable ClanMember clanMember;
    private final @Nullable UUID clanOnJoin;
}
