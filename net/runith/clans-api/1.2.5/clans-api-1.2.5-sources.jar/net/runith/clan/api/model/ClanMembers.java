package net.runith.clan.api.model;

import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

public record ClanMembers(@NotNull Set<ClanMember> members) {

    public @NotNull Collection<ClanMember> getOnlineMembers() {
        final List<ClanMember> onlineMembers = new ArrayList<>(members.size());
        for (final ClanMember member : members) {
            if (member.isOnline()) {
                onlineMembers.add(member);
            }
        }
        return onlineMembers;
    }

    public @NotNull Collection<Player> getOnlinePlayers() {
        final List<Player> onlineMembers = new ArrayList<>(members.size());
        for (final ClanMember member : members) {
            final Player player = member.getPlayer();
            if (player != null) {
                onlineMembers.add(player);
            }
        }
        return onlineMembers;
    }

    public @Nullable ClanMember getByName(final String name) {
        for (final ClanMember member : members) {
            if (member.getName().equals(name)) {
                return member;
            }
        }
        return null;
    }

    public boolean hasOnlineMembers() {
        for (final ClanMember member : members) {
            if (member.isOnline()) {
                return true;
            }
        }
        return false;
    }

    public void forEachOnlineMember(final @NotNull Consumer<ClanMember> consumer) {
        for (final ClanMember member : members) {
            if (member.isOnline()) {
                consumer.accept(member);
            }
        }
    }

    public void forEachOnlinePlayer(final @NotNull Consumer<Player> consumer) {
        for (final ClanMember member : members) {
            final Player player = member.getPlayer();
            if (player != null) {
                consumer.accept(player);
            }
        }
    }
}