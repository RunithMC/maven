package net.runith.clan.api.action;

import net.runith.clan.api.action.helper.ActionExecutorHolder;
import net.runith.clan.api.model.Clan;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public record ClanCreateAction(
    @NotNull String name,
    @NotNull Player leader,
    String tag
) {

    public static final ActionExecutorHolder<Response, ClanCreateAction> EXECUTOR = new ActionExecutorHolder<>();

    public enum ResponseStatus {
        ALREADY_EXIST,
        ALREADY_IN_CLAN,
        NAME_TO_LARGE,
        INVALID_NAME,
        INVALID_TAG,
        CREATED
    }

    public record Response(@Nullable Clan clan, @NotNull ResponseStatus status){}
}