package net.runith.clan.api.leaderboard;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;

import java.util.Collections;
import java.util.List;
import java.util.Comparator;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public final class Leaderboard {
    private final Object2IntOpenHashMap<String> scores = new Object2IntOpenHashMap<>();
    private List<Object2IntMap.Entry<String>> cachedSorted = new ObjectArrayList<>();
    private boolean dirty = true;
    private final ReadWriteLock lock = new ReentrantReadWriteLock();

    public void setScore(String player, int score) {
        lock.writeLock().lock();
        try {
            scores.put(player, score);
            dirty = true;
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void addScore(String player, int points) {
        if (points == 0) {
            return;
        }

        lock.writeLock().lock();
        try {
            scores.addTo(player, points);
            dirty = true;
        } finally {
            lock.writeLock().unlock();
        }
    }

    public int getScore(String player) {
        lock.readLock().lock();
        try {
            return scores.getOrDefault(player, 0);
        } finally {
            lock.readLock().unlock();
        }
    }

    public void remove(String player) {
        lock.writeLock().lock();
        try {
            if (scores.removeInt(player) != 0) {
                dirty = true;
            }
        } finally {
            lock.writeLock().unlock();
        }
    }

    public List<Object2IntMap.Entry<String>> getTopPlayers(int limit) {
        lock.readLock().lock();
        try {
            if (!dirty) {
                return getCachedSubList(limit);
            }
        } finally {
            lock.readLock().unlock();
        }

        lock.writeLock().lock();
        try {
            if (dirty) {
                updateCache();
            }
            return getCachedSubList(limit);
        } finally {
            lock.writeLock().unlock();
        }
    }

    private List<Object2IntMap.Entry<String>> getCachedSubList(int limit) {
        int endIndex = Math.min(limit, cachedSorted.size());
        if (endIndex == 0) {
            return Collections.emptyList();
        }
        return new ObjectArrayList<>(cachedSorted.subList(0, endIndex));
    }

    private void updateCache() {
        cachedSorted = new ObjectArrayList<>(scores.object2IntEntrySet());
        cachedSorted.sort(Comparator
            .comparingInt(Object2IntMap.Entry<String>::getIntValue)
            .reversed()
            .thenComparing(Object2IntMap.Entry::getKey));
        dirty = false;
    }

    public void clear() {
        lock.writeLock().lock();
        try {
            scores.clear();
            cachedSorted.clear();
            dirty = true;
        } finally {
            lock.writeLock().unlock();
        }
    }

    public int size() {
        lock.readLock().lock();
        try {
            return scores.size();
        } finally {
            lock.readLock().unlock();
        }
    }

    public boolean isEmpty() {
        lock.readLock().lock();
        try {
            return scores.isEmpty();
        } finally {
            lock.readLock().unlock();
        }
    }
}