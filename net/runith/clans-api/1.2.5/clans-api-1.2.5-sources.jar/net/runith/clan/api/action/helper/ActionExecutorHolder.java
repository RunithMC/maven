package net.runith.clan.api.action.helper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.function.BiConsumer;
import java.util.function.Function;

public final class ActionExecutorHolder<R, A> {

    private ClanActionExecutor<R, A> executor;
    private Collection<BiConsumer<R,A>> listeners;
    private Collection<Function<A, Boolean>> preExecutionListeners;

    public ClanActionExecutor<R, A> get() {
        return executor;
    }

    public void set(final ClanActionExecutor<R, A> executor) {
        this.executor = executor;
    }

    public R execute(final A data) {
        if (executor == null) {
            return null;
        }

        if (preExecutionListeners != null && !preExecutionListeners.isEmpty()) {
            for (final Function<A, Boolean> listener : preExecutionListeners) {
                if (listener.apply(data)) {
                    return null;
                }
            }
        }

        final R result = executor.execute(data);

        if (listeners != null && !listeners.isEmpty()) {
            for (final BiConsumer<R, A> listener : listeners) {
                listener.accept(result, data);
            }
        }
        return result;
    }

    /**
     * Adds a post-execution listener. The listener will be called after the execution of the action, with the result and the action data as parameters.
     * @param listener the listener to add
     */
    public void addListener(final BiConsumer<R, A> listener) {
        if (listeners == null) {
            listeners = new ArrayList<>();
        }
        listeners.add(listener);
    }

    /**
     * Adds a pre-execution listener. If any of the listeners returns true, the execution will be cancelled.
     * @param listener the listener to add
     */
    public void addPreExecutionListener(final Function<A, Boolean> listener) {
        if (preExecutionListeners == null) {
            preExecutionListeners = new ArrayList<>();
        }
        preExecutionListeners.add(listener);
    }
}