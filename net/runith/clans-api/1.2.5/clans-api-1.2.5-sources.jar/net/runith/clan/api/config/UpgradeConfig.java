package net.runith.clan.api.config;

import lombok.Data;

import net.runith.clan.api.model.Clan;
import net.runith.clan.api.upgrades.type.ExtraMemberUpgrade;
import net.runith.clan.api.upgrades.type.PercentageUpgrade;
import net.runith.clan.api.upgrades.type.ProbabilityUpgrade;
import net.runith.clan.api.upgrades.type.Upgrade;

import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.function.BiFunction;
import java.util.function.Supplier;

@Data
public final class UpgradeConfig {
    private BiFunction<Clan, Player, Inventory> guiCreator;
    private UpgradeItem<PercentageUpgrade> damage, resistance;
    private UpgradeItem<ExtraMemberUpgrade> extraMembers, extraEnemies, extraAllies;
    private UpgradeItem<ProbabilityUpgrade> extraKillPerEnemy;

    @Data
    public static class UpgradeItem<T extends Upgrade> {
        final T upgrade;
        char id;
        Supplier<ItemStack> itemBuilder;
    }
}