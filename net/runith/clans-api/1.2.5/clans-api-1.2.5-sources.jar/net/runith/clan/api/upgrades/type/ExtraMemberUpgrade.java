package net.runith.clan.api.upgrades.type;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExtraMemberUpgrade extends Upgrade {
    private int membersPerLevel;

    public ExtraMemberUpgrade(final String name, final int internalID) {
        super(name, internalID);
    }

    @Override
    public String toString() {
        return "membersPerLevel=" + membersPerLevel + ", " + super.toString();
    }

    public int getMembersForLevel(final int level) {
        return membersPerLevel * level;
    }
}