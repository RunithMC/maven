package net.runith.clan.api.storage;

import net.runith.clan.api.model.Clan;
import net.runith.clan.api.model.ClanMember;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Represents a storage handler for managing clans and their associated player data.
 */
public interface ClansStorage {

    /**
     * Checks whether a clan exists by its unique identifier.
     *
     * @param clanUUID the unique ID of the clan
     * @return {@code true} if the clan exists, otherwise {@code false}
     */
    boolean existsClan(@NotNull UUID clanUUID);

    /**
     * Retrieves a clan by its unique identifier.
     *
     * @param clanUUID the unique ID of the clan
     * @return the {@link Clan} instance if found, or {@code null} if not present
     */
    @Nullable Clan getClan(@NotNull UUID clanUUID);

    /**
     * Retrieves a clan by its name.
     *
     * @param clanName the name of the clan
     * @return the {@link Clan} instance if found, or {@code null} if not present
     */
    @Nullable Clan getClan(@NotNull String clanName);

    /**
     * Saves or updates a clan in the storage.
     *
     * @param clan the {@link Clan} to store
     */
    void setClan(@NotNull Clan clan);

    /**
     * Removes a clan from the storage.
     *
     * @param uuid the unique ID of the clan to remove
     * @return the removed {@link Clan} instance, or {@code null} if not found
     */
    @Nullable Clan removeClan(@NotNull UUID uuid);

    /**
     * Retrieves a clan member by their player UUID.
     *
     * @param playerUUID the unique ID of the player
     * @return the {@link ClanMember} instance if found, or {@code null} if not present
     */
    @Nullable ClanMember getMember(@NotNull UUID playerUUID);

    /**
     * Retrieves the clan-related data of a player.
     *
     * @param uuid the unique ID of the player
     * @return the {@link PlayerClanData} if available, or {@code null} otherwise
     */
    @Nullable PlayerClanData getPlayerClanData(@NotNull UUID uuid);

    /**
     * Sets or updates a player’s clan data in the storage.
     *
     * @param uuid the unique ID of the player
     * @param clanData the {@link PlayerClanData} to associate with the player
     * @return the previous {@link PlayerClanData}, or {@code null} if none existed
     */
    @Nullable PlayerClanData setPlayerClanData(@NotNull UUID uuid, @NotNull PlayerClanData clanData);


    /**
     * Sets or updates a player’s clan data in the storage.
     *
     * @param member the unique ID of the player
     * @return the previous {@link PlayerClanData}, or a new if none existed
     */
    @NotNull PlayerClanData updatePlayerClanData(@NotNull ClanMember member);

    /**
     * Removes a player’s clan data from the storage.
     *
     * @param uuid the unique ID of the player
     * @return the removed {@link PlayerClanData}, or {@code null} if not found
     */
    @Nullable PlayerClanData removePlayerClanData(@NotNull UUID uuid);

    /**
     * Retrieves all currently active or loaded clans in the system.
     *
     * @return a non-null list of online {@link Clan} instances
     */
    @NotNull List<Clan> getOnlineClans();

    /**
     * Performs the given action for each currently active or loaded clan in the system.
     * @param action the action to perform for each online clan
     */
    void forEachOnlineClan(@NotNull Consumer<@NotNull Clan> action);

    /**
     * Clears any cached clan data, forcing subsequent retrievals to fetch fresh data from the underlying storage.
     */
    void clearCache();

    @NotNull Collection<ClanMember> getOnlineMembers();
}