package net.runith.clan.api.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import net.runith.clan.api.model.Clan;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@EqualsAndHashCode(callSuper = true)
@Data
public final class ClanAllyAddEvent extends Event {
    private static final HandlerList HANDLER_LIST = new HandlerList();
    private final Clan clan1;
    private final Clan clan2;

    public ClanAllyAddEvent(final Clan clan1, final Clan clan2) {
        super(true);
        this.clan1 = clan1;
        this.clan2 = clan2;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLER_LIST;
    }

    public static HandlerList getHandlerList() {
        return HANDLER_LIST;
    }
}