package net.runith.clan.api.leaderboard;

import lombok.Data;

@Data
public final class Leaderboards {
    private Leaderboard
        kills = new Leaderboard(),
        deaths = new Leaderboard(),
        score = new Leaderboard(),
        points = new Leaderboard();

    public void remove(final String name) {
        kills.remove(name);
        deaths.remove(name);
        score.remove(name);
        points.remove(name);
    }

    public void change(final String name, final String newName) {
        kills.setScore(newName, kills.getScore(name));
        deaths.setScore(newName, deaths.getScore(name));
        score.setScore(newName, score.getScore(name));
        points.setScore(newName, points.getScore(name));

        kills.remove(name);
        deaths.remove(name);
        score.remove(name);
        points.remove(name);
    }
}