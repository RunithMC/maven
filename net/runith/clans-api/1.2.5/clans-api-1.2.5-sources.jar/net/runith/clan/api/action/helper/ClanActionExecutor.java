package net.runith.clan.api.action.helper;

public interface ClanActionExecutor<R, D> {
    R execute(D data);

    Class<D> actionClass();
}