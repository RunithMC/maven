package net.runith.clan.api.util;

@FunctionalInterface
public interface ObjectToInt<T> {
    int apply(final T object);
}
