package net.runith.clan.api.action;

import net.runith.clan.api.action.helper.ActionExecutorHolder;
import net.runith.clan.api.model.Clan;
import net.runith.clan.api.model.ClanMember;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public record ClanRenameAction(
    @NotNull ClanMember member,
    @NotNull String name,
    @NotNull String tag
) {

    public static final ActionExecutorHolder<ClanRenameAction.Response, ClanRenameAction> EXECUTOR = new ActionExecutorHolder<>();

    public enum ResponseStatus {
        ALREADY_EXIST,
        NAME_TO_LARGE,
        INVALID_NAME,
        INVALID_TAG,
        RENAMED
    }

    public record Response(@Nullable Clan clan, @NotNull ClanRenameAction.ResponseStatus status){}
}
