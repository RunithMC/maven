package net.runith.clan.api.model;

public enum Permissions {
    USER_UPGRADE("user.upgrade"),
    USER_TAG("user.tag"),
    USER_SETROLE("user.setrole"),
    USER_RENAME("user.rename"),
    USER_RALLY("user.rally"),
    USER_LIST("user.list"),
    USER_LEAVE("user.leave"),
    USER_KICK("user.kick"),
    USER_INVITE("user.invite"),
    USER_INFO("user.info"),
    USER_FRIENDLYFIRE("user.friendlyfire"),
    USER_ENEMY("user.enemy"),
    USER_DISBAND("user.disband"),
    USER_CREATE("user.create"),
    USER_CHAT("user.chat"),
    USER_BASE("user.base"),
    USER_BANK("user.bank"),
    USER_ALLY("user.ally"),
    USER_USE("user.use"),

    ADMIN_USE("admin.use"),
    ADMIN_STATS("admin.stats"),
    ADMIN_RELOAD("admin.reload"),
    ADMIN_JOIN("admin.join"),
    ADMIN_MIGRATE("admin.migrate"),
    ADMIN_DELETE("admin.delete"),
    ADMIN_CHATSPY("admin.chatspy"),
    ADMIN_CHANGETAG("admin.changetag");

    private final String perm;

    Permissions(String perm) {
        this.perm = perm;
    }

    public final String getPermission() {
        return "runithclans." + this.perm;
    }
}