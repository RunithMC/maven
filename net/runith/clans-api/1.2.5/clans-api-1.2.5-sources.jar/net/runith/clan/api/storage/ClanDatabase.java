package net.runith.clan.api.storage;

import net.runith.clan.api.model.Clan;
import net.runith.clan.api.model.PlayerInClanEntity;
import net.runith.database.repository.sync.Repository;

import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.CompletableFuture;

public interface ClanDatabase {
    /**
     * Enables or disables the autosave feature, which automatically saves cached data to the database at regular intervals.
     */
    void setAutosaveEnabled(boolean enabled);

    /**
     * Checks if the autosave feature is currently enabled.
     * @return {@code true} if autosave is enabled, otherwise {@code false}
     */
    boolean isAutosaveEnabled();

    /**
     * Saves async any cached data to the database
     */
    CompletableFuture<?> saveCachedDataAsync();

    /**
     * Gets the executor service used for asynchronous database operations.
     * @return the executor service instance
     */
    ExecutorService getExecutorService();

    /**
     * @return the repository instance for player-in-clan entities
     */
    Repository<UUID, PlayerInClanEntity> getPlayerInClanEntityRepository();

    /**
     * @return the repository instance for clans
     */
    Repository<UUID, Clan> getClanRepository();
}
