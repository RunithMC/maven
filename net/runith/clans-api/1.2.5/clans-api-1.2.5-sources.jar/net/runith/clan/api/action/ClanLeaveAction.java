package net.runith.clan.api.action;

import net.runith.clan.api.action.helper.ActionExecutorHolder;
import net.runith.clan.api.model.Clan;
import net.runith.clan.api.model.ClanMember;
import org.jetbrains.annotations.NotNull;

public record ClanLeaveAction(@NotNull ClanMember member) {
    public static final ActionExecutorHolder<Clan, ClanLeaveAction> EXECUTOR = new ActionExecutorHolder<>();
}
