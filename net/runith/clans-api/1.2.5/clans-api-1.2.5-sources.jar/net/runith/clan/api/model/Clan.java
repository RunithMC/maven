package net.runith.clan.api.model;

import io.netty.util.internal.ConcurrentSet;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import net.runith.clan.api.upgrades.ClanUpgrades;
import net.runith.clan.api.upgrades.type.Upgrade;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

@RequiredArgsConstructor
@Getter
@Setter
@ToString
public final class Clan {
    /** UUID is generated using {@link net.runith.clan.api.util.StringUtil#stringToUUID(String)} */
    private final @NotNull UUID uuid;

    private final @NotNull String name;
    private final @NotNull ClanMembers clanMembers;

    private @Nullable String tag;
    private int kills, deaths, points;
    private final AtomicLong balance = new AtomicLong(0);

    private boolean friendlyFire = false;

    private final int[] upgradesLevels = new int[ClanUpgrades.MAX_ID];
    private final Set<String> enemies = new ConcurrentSet<>();
    private final Set<String> allies = new ConcurrentSet<>();

    private @Nullable Location base;

    private @Nullable ClanRally clanRally;

    private volatile long lastRename;

    public boolean hasActiveRally() {
        return clanRally != null;
    }

    public void clearActiveRally() {
        clanRally = null;
    }

    public boolean isAlly(final @NotNull Clan otherClan) {
        return allies.contains(otherClan.getName());
    }

    public boolean isEnemy(final @NotNull Clan otherClan) {
        return enemies.contains(otherClan.getName());
    }

    public String getTag() {
        return tag == null ? name : tag;
    }

    public void setTag(@Nullable String tag) {
        if (tag != null) {
            tag = ChatColor.translateAlternateColorCodes('&', tag);
        }
        this.tag = tag;
    }

    public int getUpgradeLevel(int id) {
        return id >= upgradesLevels.length ? 0 : upgradesLevels[id];
    }

    public int getUpgradeLevel(Upgrade upgrade) {
        return getUpgradeLevel(upgrade.getId());
    }

    public void setLevel(int id, int level) {
        this.upgradesLevels[id] = level;
    }

    // Thread-safe balance operations
    public long getBalance() {
        return balance.get();
    }

    public void setBalance(long value) {
        balance.set(value);
    }

    public long addBalance(long amount) {
        return balance.addAndGet(amount);
    }

    public long subtractBalance(long amount) {
        return balance.addAndGet(-amount);
    }

    /**
     * Atomically subtracts the given amount if the current balance is >= amount.
     * @return true if successful, false if insufficient balance
     */
    public boolean trySubtractBalance(long amount) {
        long current;
        do {
            current = balance.get();
            if (current < amount) {
                return false;
            }
        } while (!balance.compareAndSet(current, current - amount));
        return true;
    }

    @Override
    public boolean equals(final Object obj) {
        return obj instanceof Clan clan && clan.uuid.equals(this.uuid);
    }

    @Override
    public int hashCode() {
        return uuid.hashCode();
    }

    public UUID getId() {
        return this.uuid;
    }
}