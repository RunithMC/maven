package net.runith.clan.api.model;

public enum ChatMode {
    GLOBAL,
    CLAN,
    ENEMY,
    ALLY
}
