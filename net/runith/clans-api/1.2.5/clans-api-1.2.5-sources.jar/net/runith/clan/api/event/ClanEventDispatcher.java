package net.runith.clan.api.event;

import lombok.experimental.UtilityClass;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;

@UtilityClass
public final class ClanEventDispatcher {

    public static void callEvent(final Event event) {
        if (Bukkit.isPrimaryThread()) {
            Thread.ofVirtual().start(() -> {
                try {
                    Bukkit.getPluginManager().callEvent(event);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        } else {
            Bukkit.getPluginManager().callEvent(event);
        }
    }
}
