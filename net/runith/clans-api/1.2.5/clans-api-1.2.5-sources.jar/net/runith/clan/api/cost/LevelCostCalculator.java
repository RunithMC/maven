package net.runith.clan.api.cost;


import java.util.function.IntToLongFunction;

public final class LevelCostCalculator {

    private final int maxLevel;
    private final IntToLongFunction costPerLevel;
    private final CostFunctions.CumCost cumCost;

    public LevelCostCalculator(IntToLongFunction unit, CostFunctions.CumCost cum, int maxLevel) {
        this.maxLevel = maxLevel;
        this.costPerLevel = unit;
        this.cumCost = cum;
    }

    public LevelCostCalculator(CostFunctions.CostPair pair, int maxLevel) {
        this.maxLevel = maxLevel;
        this.costPerLevel = pair.unit;
        this.cumCost = pair.cum;
    }

    public long costForLevel(int level) {
        return costPerLevel.applyAsLong(level);
    }

    public long costToReach(int fromLevel, int toLevel) {
        if (toLevel <= fromLevel) return 0L;
        return cumCost.sum(fromLevel, toLevel);
    }

    public long costForNextLevels(int startLevel, int levels) {
        int toLevel = Math.min(maxLevel, startLevel + levels);
        return costToReach(startLevel, toLevel);
    }

    public int maxAffordableLevelFrom(int startLevel, long moneyAvailable) {
        int low = startLevel + 1, high = maxLevel, best = startLevel;
        while (low <= high) {
            int mid = low + ((high - low) >>> 1);
            long total = costToReach(startLevel, mid);
            if (total <= moneyAvailable) {
                best = mid;
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return best - startLevel;
    }

    public int maxLevel() {
        return maxLevel;
    }
}