package net.runith.clan.api.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import net.runith.clan.api.model.Clan;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@EqualsAndHashCode(callSuper = true)
@Data
public final class ClanEnemyRemoveEvent extends Event {
    private static final HandlerList HANDLER_LIST = new HandlerList();
    private final Clan clan;
    private final String enemy;

    public ClanEnemyRemoveEvent(final Clan clan, final String enemy) {
        super(false);
        this.clan = clan;
        this.enemy = enemy;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLER_LIST;
    }

    public static HandlerList getHandlerList() {
        return HANDLER_LIST;
    }
}