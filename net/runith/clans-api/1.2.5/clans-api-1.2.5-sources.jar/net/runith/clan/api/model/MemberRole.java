package net.runith.clan.api.model;

public enum MemberRole {
    ADMINISTRATOR(4),
    LEADER(3),
    CO_LEADER(2),
    MOD(1),
    USER(0);

    private final int priority;

    MemberRole(int priority) {
        this.priority = priority;
    }

    public int priority() {
        return priority;
    }
}