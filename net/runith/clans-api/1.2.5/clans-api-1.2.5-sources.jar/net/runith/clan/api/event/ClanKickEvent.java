package net.runith.clan.api.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import net.runith.clan.api.model.Clan;
import net.runith.clan.api.model.ClanMember;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@EqualsAndHashCode(callSuper = true)
@Data
public final class ClanKickEvent extends Event {
    private static final HandlerList HANDLER_LIST = new HandlerList();
    private final ClanMember clanMember;
    private final Player kickedBy;
    private final String reason;

    public ClanKickEvent(final ClanMember clanMember, final Player kickedBy, final String reason) {
        super(false);
        this.clanMember = clanMember;
        this.kickedBy = kickedBy;
        this.reason = reason;
    }

    public Clan getClan() {
        return clanMember.getClan();
    }

    public Player getPlayer() {
        return clanMember.getPlayer();
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLER_LIST;
    }

    public static HandlerList getHandlerList() {
        return HANDLER_LIST;
    }
}