package net.runith.clan.api.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import net.runith.clan.api.model.Clan;
import net.runith.clan.api.model.ClanMember;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

@EqualsAndHashCode(callSuper = true)
@Data
public final class ClanLeaveEvent extends Event {
    private static final HandlerList HANDLER_LIST = new HandlerList();
    private final ClanMember clanMember;

    public ClanLeaveEvent(final ClanMember clanMember) {
        super(false);
        this.clanMember = clanMember;
    }

    public Clan getClan() {
        return clanMember.getClan();
    }

    public Player getPlayer() {
        return clanMember.getPlayer();
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLER_LIST;
    }

    public static HandlerList getHandlerList() {
        return HANDLER_LIST;
    }
}