package net.runith.clan.api.upgrades.type;

import lombok.Data;
import net.runith.clan.api.cost.LevelCostCalculator;

@Data
public class Upgrade {
    private final String name;
    private final int id;
    private boolean enable;
    private String displayName;

    private int maxLevel;
    private LevelCostCalculator costCalculator;

    public long calculateCost(final int level) {
        return costCalculator.costForLevel(level+1);
    }
}