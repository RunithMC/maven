package net.runith.clan.api.config;

import lombok.Data;

@Data
public final class ChatConfig {
    private String clanPrefix;
    private String enemyReceivePrefix;
    private String enemySendPrefix;

    private String allyReceivePrefix;
    private String allySendPrefix;
}

