package net.runith.clan.api.util;

import lombok.experimental.UtilityClass;

import java.util.regex.Pattern;

@UtilityClass
public final class ClanNameChecker {
    private static final Pattern VALID_NAMES_PATTERN = Pattern.compile("^[a-zA-Z0-9._\\-@#!?$%&*+=:;/\\\\|^~]+$");

    public static boolean isValidTag(final String tag) {
        return tag != null && tag.length() <= 32 && VALID_NAMES_PATTERN.matcher(tag).matches();
    }

    public static boolean isValidName(final String name) {
        return name != null && name.length() <= 16 && VALID_NAMES_PATTERN.matcher(name).matches();
    }
}