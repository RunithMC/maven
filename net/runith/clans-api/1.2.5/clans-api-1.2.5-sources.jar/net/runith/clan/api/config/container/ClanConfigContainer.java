package net.runith.clan.api.config.container;

public interface ClanConfigContainer<T> {
    T getConfig();

    void load();
}
