package net.runith.clan.api.upgrades.type;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PercentageUpgrade extends Upgrade {
    private double percentagePerLevel;
    private double basePercentage;

    public PercentageUpgrade(final String name, final int internalID) {
        super(name, internalID);
    }

    public double calculatePercentage(final int level) {
        return (basePercentage + percentagePerLevel) * level;
    }

    public String toString() {
        return "percentagePerLevel=" + percentagePerLevel + ", basePercentage=" + basePercentage + ", " + super.toString();
    }
}