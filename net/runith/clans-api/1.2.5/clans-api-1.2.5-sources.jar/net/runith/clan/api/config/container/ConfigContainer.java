package net.runith.clan.api.config.container;

import net.runith.clan.api.config.ChatConfig;
import net.runith.clan.api.config.ClanConfig;
import net.runith.clan.api.config.UpgradeConfig;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class ConfigContainer {
    private final Map<Class<?>, ClanConfigContainer<?>> configMap = new ConcurrentHashMap<>();

    public void load() {
        configMap.values().forEach(ClanConfigContainer::load);
    }

    public <T> void addConfig(Class<T> configClass, ClanConfigContainer<T> config) {
        configMap.put(configClass, config);
    }

    public <T> void addConfig(ClanConfigContainer<T> config) {
        configMap.put(config.getConfig().getClass(), config);
    }

    public void unregisterConfig(Class<?> configClass) {
        configMap.remove(configClass);
    }

    public <T> T getConfig(final Class<T> configClass) {
        final ClanConfigContainer<?> obj = configMap.get(configClass);
        if (obj == null) {
            return null;
        }
        return configClass.cast(obj.getConfig());
    }

    public ClanConfig getClanConfig() {
        return getConfig(ClanConfig.class);
    }

    public ChatConfig getChatConfig() {
        return getConfig(ChatConfig.class);
    }

    public UpgradeConfig getUpgradeConfig() {
        return getConfig(UpgradeConfig.class);
    }
}
